package com.programvaruprojekt.springbatchtutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbatchtutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
