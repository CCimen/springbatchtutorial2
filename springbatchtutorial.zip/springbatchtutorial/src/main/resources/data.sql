INSERT INTO PERSON (first_name, last_name, age) VALUES ('John', 'Doe', 25);
INSERT INTO PERSON (first_name, last_name, age) VALUES ('Michael', 'Doe', 25);
INSERT INTO PERSON (first_name, last_name, age) VALUES ('Steven', 'Doe', 25);
INSERT INTO PERSON (first_name, last_name, age) VALUES ('Johnny', 'Doe', 25);