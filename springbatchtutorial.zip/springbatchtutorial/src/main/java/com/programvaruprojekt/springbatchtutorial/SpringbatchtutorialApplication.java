package com.programvaruprojekt.springbatchtutorial;

import com.programvaruprojekt.springbatchtutorial.model.Person;
import com.programvaruprojekt.springbatchtutorial.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SpringbatchtutorialApplication {

	@Autowired
	private PersonRepository personRepository;

	public static void main(String[] args) {
		ConfigurableApplicationContext configurableApplicationContext =
		SpringApplication.run(SpringbatchtutorialApplication.class, args);
		PersonRepository personRepository = configurableApplicationContext.getBean(PersonRepository.class);

		Person person = new Person("John", "Doe", 25);
		personRepository.save(person);
	}

}
